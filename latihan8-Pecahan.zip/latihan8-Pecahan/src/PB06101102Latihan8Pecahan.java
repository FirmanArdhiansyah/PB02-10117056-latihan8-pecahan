/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Firman Ardhiansyah IF-2 10117056
 */
public class PB06101102Latihan8Pecahan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      float f;
      double d;
      f = 1234567890.123456789f;
      d = 1_234_567_890.123456789;
      System.out.println("FLOAT : " + f);
      System.out.println("DOUBLE : " + d);
      
    
 
    }
    
}
